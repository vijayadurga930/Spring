/*
 * package com.cg;
 * 
 * import java.util.List;
 * 
 * public class Circle {
 * 
 * 
 * private point center;
 * 
 * 
 * public point getCenter() { return center; }
 * 
 * public void setCenter(point center) { this.center = center; }
 * 
 * 
 * 
 * private List<point> points;
 * 
 * public List<point> getPoints() { return points; }
 * 
 * public void setPoints(List<point> points) { this.points = points; }
 * 
 * 
 * public void draw() { System.out.println("cicle drawn"); System.out.println();
 * } }
 */


package com.cg;

 
import java.util.List;

 

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

 

public class Circle implements BeanNameAware, BeanFactoryAware, InitializingBean, DisposableBean,ApplicationContextAware{

 

    /*
     * private List<Point> points;
     * 
     * 
     * public Point getCenter() { return center; }
     * 
     * public void setCenter(Point center) { this.center = center; }
     * 
     * public Circle() { super(); // TODO Auto-generated constructor stub }
     * 
     * public Circle(Point center) { super(); this.center = center; }
     * 
     * 
     * public void draw() {
     * 
     * for(Point point:points)
     * System.out.println("Point ("+point.getX()+","+point.getY()+")");
     * //System.out.println("Circle Drawn");
     * //System.out.println("Circle Points ("+center.getX()+","+center.getY()); }
     */
    /*
     * public Circle(List<Point> points) { super(); this.points = points; }
     * 
     * public List<Point> getPoints() { return points; }
     * 
     * public void setPoints(List<Point> points) { this.points = points; }
     */
    private point center;
    

 

    public void draw() {
        System.out.println("Circle Drawn");
        System.out.println("Circle Points("+center.getX()+","+center.getY()+")");
    }
    public point getCenter() {
        return center;
    }

 

    public void setCenter(point center) {
        this.center = center;
    }

 

    @Override
    public void setBeanName(String beanName) {
        System.out.println(beanName);

 

    }

 

    @Override
    public void setBeanFactory(BeanFactory bF) throws BeansException {
        System.out.println("Set BeanFactory method called by the container");

 

    }

 

    @Override
    public void afterPropertiesSet() throws Exception {

 

    }

 

    public void startUp() {
        System.out.println("My init method executed");
    }

 

    @Override
    public void destroy() throws Exception {
        System.out.println("Destroyed method of Disposable bean");

 

    }

 

    public void myDestroy() {
        System.out.println("My destroy method execute");
    }
    @Override
    public void setApplicationContext(ApplicationContext arg0) throws BeansException {
        System.out.println("Set application context");
        
    }

 

}