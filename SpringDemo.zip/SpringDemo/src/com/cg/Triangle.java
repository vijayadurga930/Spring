package com.cg;

import java.util.List;

public class Triangle {
	
	/*
	 * private String type; private int height;
	 * 
	 * public int getHeight() { return height; }
	 * 
	 * 
	 * public void setHeight(int height) { this.height = height; }
	 * 
	 * 
	 * public String getType() { return type; }
	 * 
	 * 
	 * public Triangle(String type) { super();
	 * 
	 * } public Triangle(int height) { super(); }
	 * 
	 * 
	 * public Triangle(String type, int height) { super(); this.type = type;
	 * this.height = height; }
	 * 
	 * 
	 * public void setType(String type) { this.type = type; }
	 */
	 
	
	/*
	 * public void draw() { System.out.println(type+ "Triangle drawnn of height "
	 * +height); }
	 */

	
	
	
	  private point pointA; 
	  private point pointB; 
	  private point pointC; 
	  public point getPointA() {
		  return pointA;
		  }
	  public void setPointA(point pointA) 
	  {
	  this.pointA = pointA; 
	  } public point getPointB() {
		  return pointB;
		  }
	  public void setPointB(point pointB) {
		  this.pointB = pointB;
		  } public point getPointC() {
			  return pointC;
			  } public void setPointC(point pointC) {
	  this.pointC = pointC;
	  }
	 
	
	
	  private List<point> points;
	  
	  public List<point> getPoints() { return points; }
	  
	  public void setPoints(List<point> points) { this.points = points; }
	 
	  
	  public void draw() {
	        /*
	         * for (Point point:points) {
	         * System.out.println("Point("+point.getX()+","+point.getY()+")");
	         * 
	         * }
	         */
	        System.out.println("pointA("+pointA.getX()+","+pointA.getY()+")");
	        System.out.println("pointB("+pointB.getX()+","+pointB.getY()+")");
	        System.out.println("pointC("+pointC.getX()+","+pointC.getY()+")");
	    }
	}