package com.cg;

import java.sql.Date;

public class Employee {
	
private Date dob;

public Employee() {
	super();
	// TODO Auto-generated constructor stub
}

public Date getDob() {
	return dob;
}

public void setDob(Date dob) {
	this.dob = dob;
}


}
