package com.cg.cust.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.cust.dto.Customerr;
import com.cg.cust.exception.CustomerException;
import com.cg.cust.service.CustomerService;

@Controller
/*@RequestMapping("/greet")*/
public class CustomerController {
	@Autowired
	private CustomerService customerservice;
@RequestMapping("/hellojessie")
	public String Hellojessie() {
		return "greet";
		
	}
@RequestMapping("/")
public ModelAndView ShowAllCustomers() {
	List<Customerr> customers;
	try {
		customers = customerservice.getAllCustomers();
		ModelAndView mv = new ModelAndView("index");
		mv.addObject("customerr",customers);
		return mv;
	} catch (CustomerException e) {
		ModelAndView mv = new ModelAndView("error");
		mv.addObject("errorr",e);
		return mv;
	}
}

@RequestMapping("/delete")
 public ModelAndView deleteCustomer(@RequestParam int id) {
	try {
		List<Customerr> customers=customerservice.deleteCustomer(id);
		ModelAndView mv = new ModelAndView("index");
		mv.addObject("customerr",customers);
		return mv;
	} catch (CustomerException e) {
		ModelAndView mv = new ModelAndView("error");
		mv.addObject("errorr",e);
		return mv;
	}
}
@RequestMapping("/addCustomer")	
public String showAddForm(Model model) {
	model.addAttribute("customerr",new Customerr() );
	return "add";
}

@RequestMapping(value="/add",method = RequestMethod.POST)
public ModelAndView addCustomer(@Valid @ModelAttribute Customerr customer,BindingResult result ) {
	try {
		if(result.hasErrors()) {
			return new ModelAndView("add","customerr",customer);
		}
	
	List<Customerr> customers=customerservice.addCustomer(customer);
	return new ModelAndView("index","customerr",customers);
	
	
	} catch (Exception e) {
		ModelAndView mv = new ModelAndView("error");
		mv.addObject("errorr",e);
		return mv;
	}
}



@RequestMapping("/update")	
public String showUpdateForm(@RequestParam int id ,Model model) {
	Customerr customer;
	customer=customerservice.getCustomerById(id);
	model.addAttribute("customerr",customer);
	return "update";
}



@RequestMapping(value="/updateCustomer",method = RequestMethod.POST)
public ModelAndView updateCustomer(@Valid @ModelAttribute Customerr customer,BindingResult result ) {
	try {
		if(result.hasErrors()) {
			return new ModelAndView("update","customerr",customer);
		}
	
	List<Customerr> customers=customerservice.addCustomer(customer);
	return new ModelAndView("index","customerr",customers);
	
	
	} catch (Exception e) {
		ModelAndView mv = new ModelAndView("error");
		mv.addObject("errorr",e);
		return mv;
	}
}
}
