package com.cg.cust.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.cust.dto.Customerr;

public interface CustomerRepository  extends JpaRepository<Customerr, Integer>{

}
