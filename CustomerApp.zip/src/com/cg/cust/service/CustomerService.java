package com.cg.cust.service;

import java.util.List;

import com.cg.cust.dto.Customerr;
import com.cg.cust.exception.CustomerException;

public interface CustomerService {
	
	
	
	List<Customerr> getAllCustomers() throws CustomerException;
    List<Customerr> deleteCustomer(int id) throws CustomerException;
    List<Customerr> addCustomer(Customerr customer) throws CustomerException;
    List<Customerr> updateCustomer(Customerr customer)throws CustomerException;
	Customerr getCustomerById(int id);
    
}
