package com.cg.cust.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.cust.dao.CustomerRepository;
import com.cg.cust.dto.Customerr;
import com.cg.cust.exception.CustomerException;
@Service
public class CustomerServiceImpl implements  CustomerService{
	@Autowired
private CustomerRepository customerDao;
	
	
	@Override
	public List<Customerr> getAllCustomers() throws CustomerException {
		// TODO Auto-generated method stub
		try {
			return customerDao.findAll();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new CustomerException(e.getMessage());
		}
	}


	@Override
	public List<Customerr> deleteCustomer(int id) throws CustomerException {
	
		 try {
			customerDao.delete(id);
			return getAllCustomers();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new CustomerException(e.getMessage());
		}
	}
	@Override
	public List<Customerr> addCustomer(Customerr customer) throws CustomerException {
	try {
		customerDao.save(customer);
			return getAllCustomers();
	} catch (Exception e) {
		throw new CustomerException(e.getMessage());
	}
	}


	@Override
	public List<Customerr> updateCustomer(Customerr customer) throws CustomerException {
		
		
		try {
			customerDao.save(customer);
			return getAllCustomers();
		} catch (Exception e) {
			throw new CustomerException(e.getMessage());
		}
	}


	@Override
	public Customerr getCustomerById(int id) {
		
		return customerDao.findOne(id);
	}

}
