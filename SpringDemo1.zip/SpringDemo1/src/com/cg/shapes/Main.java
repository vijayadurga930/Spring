package com.cg.shapes;

import java.util.Locale;

import org.springframework.context.ApplicationContext;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		ApplicationContext context= new ClassPathXmlApplicationContext("spring.xml");
		
		/*
		 * Circle c=(Circle) context.getBean("circle"); c.draw();
		 * 
		 * System.out.println("done");
		 */
		MessageSource messageSource=(MessageSource)context.getBean("messageSource");
		Locale locale= new Locale("in","HN");
		
		String message=messageSource.getMessage("welcome.message", null,"Default",locale);
		System.out.println(message);
		
		
		
	}

}
