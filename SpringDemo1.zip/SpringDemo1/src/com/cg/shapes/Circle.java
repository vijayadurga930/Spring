package com.cg.shapes;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;



public class Circle {
	
	@Autowired
	  private Point center;
	
	@Autowired
	MessageSource messageSource;

	    public Point getCenter() {
	        return center;
	    }

	 

	    public void setCenter(Point center) {
	        this.center = center;
	    }
	    @Required
	    public void draw() {
	    	
	    String message=messageSource.getMessage("greeting", null,"DefaultMessage", null);
	    System.out.println(message);
	    String draw=messageSource.getMessage("circle.drawing", null,"Default message", null);
	    String points=messageSource.getMessage("circle.points", new Object[] {center.getX(),center.getY()},"Default Msg", null);
	    System.out.println(points);
	    System.out.println(draw);
		/*
		 * System.out.println("Circle Drawn");
		 * System.out.println("Circle Points ("+center.getX()+","+center.getY()+")");
		 */
	       
	        
	    }
	    @PostConstruct
	    public void mtInit() {
	    	System.out.println("My Init method executed");
	    }
	    @PreDestroy
	    public void myDestroy() {
	    	System.out.println("My Destroy method executed");
	    }
	}

