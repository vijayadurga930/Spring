package com.cg.shapes;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.cg.shapes")
public class SpringConfig {
	
	@Bean
	public Point center() {
		Point p=new Point();
		p.setX(120);
		p.setY(160);
		return p;
	}
	
	@Bean
	public Circle circle() {
		Circle c=new Circle();
		return c;
	}

}
